import { StudyMaterial, Category } from '@/types';

export const categories: Category[] = [
  {
    id: '1',
    name: 'Engineering',
    description: 'Civil, Mechanical, Electrical, Computer Science',
    icon: '⚙️',
    materialCount: 245
  },
  {
    id: '2',
    name: 'Medical',
    description: 'MBBS, Nursing, Pharmacy, Dentistry',
    icon: '🏥',
    materialCount: 189
  },
  {
    id: '3',
    name: 'Government Exams',
    description: 'UPSC, SSC, Banking, Railway',
    icon: '📚',
    materialCount: 312
  },
  {
    id: '4',
    name: 'School Level',
    description: 'CBSE, ICSE, State Boards',
    icon: '🎒',
    materialCount: 467
  },
  {
    id: '5',
    name: 'Competitive Programming',
    description: 'DSA, Algorithms, Problem Solving',
    icon: '💻',
    materialCount: 156
  },
  {
    id: '6',
    name: 'Language Learning',
    description: 'English, Hindi, Foreign Languages',
    icon: '🌐',
    materialCount: 98
  }
];

export const studyMaterials: StudyMaterial[] = [
  {
    id: '1',
    title: 'Complete Civil Engineering Handbook 2024',
    description: 'Comprehensive guide covering all major topics in civil engineering including structural analysis, construction management, and geotechnical engineering.',
    category: 'Engineering',
    subject: 'Civil Engineering',
    fileType: 'PDF',
    fileSize: '15.2 MB',
    downloadUrl: '/materials/civil-engineering-handbook.pdf',
    previewUrl: '/preview/civil-engineering-handbook',
    uploadDate: '2024-10-15',
    rating: 4.8,
    downloadCount: 1247,
    tags: ['civil', 'engineering', 'handbook', 'structures'],
    author: 'Dr. Rajesh Kumar',
    pages: 345,
    language: 'English',
    level: 'Intermediate',
    thumbnail: '/images/civil-eng.jpg'
  },
  {
    id: '2',
    title: 'UPSC Prelims Previous Year Papers (2010-2023)',
    description: 'Collection of UPSC preliminary examination question papers with detailed solutions and answer keys.',
    category: 'Government Exams',
    subject: 'UPSC',
    fileType: 'ZIP',
    fileSize: '28.7 MB',
    downloadUrl: '/materials/upsc-prelims-papers.zip',
    uploadDate: '2024-10-10',
    rating: 4.9,
    downloadCount: 2893,
    tags: ['upsc', 'prelims', 'previous-year', 'government'],
    author: 'IAS Academy',
    pages: 0,
    language: 'English & Hindi',
    level: 'Advanced',
    thumbnail: '/images/upsc.jpg'
  },
  {
    id: '3',
    title: 'Data Structures and Algorithms - Complete Notes',
    description: 'Detailed notes on data structures, algorithms, complexity analysis with code examples in multiple programming languages.',
    category: 'Competitive Programming',
    subject: 'Computer Science',
    fileType: 'PDF',
    fileSize: '8.5 MB',
    downloadUrl: '/materials/dsa-complete-notes.pdf',
    uploadDate: '2024-10-08',
    rating: 4.7,
    downloadCount: 3124,
    tags: ['dsa', 'algorithms', 'programming', 'computer-science'],
    author: 'Prof. Sanjay Mehta',
    pages: 210,
    language: 'English',
    level: 'Intermediate',
    thumbnail: '/images/dsa.jpg'
  },
  {
    id: '4',
    title: 'Class 12 Physics Formula Sheet',
    description: 'Comprehensive formula sheet covering all chapters of Class 12 Physics with derivations and examples.',
    category: 'School Level',
    subject: 'Physics',
    fileType: 'PDF',
    fileSize: '3.2 MB',
    downloadUrl: '/materials/class12-physics-formulas.pdf',
    uploadDate: '2024-10-05',
    rating: 4.6,
    downloadCount: 1876,
    tags: ['physics', 'class12', 'formulas', 'cbse'],
    author: 'Physics Wallah',
    pages: 45,
    language: 'English',
    level: 'Beginner',
    thumbnail: '/images/physics.jpg'
  },
  {
    id: '5',
    title: 'Medical Biochemistry Lecture Notes',
    description: 'Detailed lecture notes covering all major topics in medical biochemistry for MBBS students.',
    category: 'Medical',
    subject: 'Biochemistry',
    fileType: 'PDF',
    fileSize: '12.8 MB',
    downloadUrl: '/materials/medical-biochemistry.pdf',
    uploadDate: '2024-10-03',
    rating: 4.8,
    downloadCount: 945,
    tags: ['medical', 'biochemistry', 'mbbs', 'lecture-notes'],
    author: 'Dr. Priya Sharma',
    pages: 289,
    language: 'English',
    level: 'Intermediate',
    thumbnail: '/images/biochemistry.jpg'
  },
  {
    id: '6',
    title: 'Banking Awareness Complete Guide 2024',
    description: 'Complete guide for banking exams covering banking history, current affairs, financial terms and more.',
    category: 'Government Exams',
    subject: 'Banking',
    fileType: 'PDF',
    fileSize: '9.3 MB',
    downloadUrl: '/materials/banking-awareness.pdf',
    uploadDate: '2024-09-28',
    rating: 4.5,
    downloadCount: 1678,
    tags: ['banking', 'awareness', 'government-exams', 'finance'],
    author: 'Bankers Point',
    pages: 156,
    language: 'English',
    level: 'Beginner',
    thumbnail: '/images/banking.jpg'
  }
];