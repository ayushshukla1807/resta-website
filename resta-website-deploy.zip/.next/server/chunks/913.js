exports.id=913,exports.ids=[913],exports.modules={5913:(t,e,r)=>{"use strict";r.r(e),r.d(e,{default:()=>App});var n=r(997);r(6764);var o=r(6689);let a=`
  body { 
    background: #000 !important; 
    color: #fff !important;
    font-family: system-ui, sans-serif;
  }
  .glass {
    background: rgba(255,255,255,0.05) !important;
    backdrop-filter: blur(10px) !important;
    border: 1px solid rgba(255,255,255,0.1) !important;
  }
  .gradient-text {
    background: linear-gradient(135deg, #22c55e, #3b82f6) !important;
    -webkit-background-clip: text !important;
    -webkit-text-fill-color: transparent !important;
  }
`;function App({Component:t,pageProps:e}){return(0,o.useEffect)(()=>{if(!document.querySelector("#emergency-styles")){let t=document.createElement("style");t.id="emergency-styles",t.textContent=a,document.head.appendChild(t)}},[]),n.jsx(t,{...e})}},6764:()=>{}};